# PrecisionFix (Node / Electron)

## Rodar
    npm install
    npm start

## Gerar .exe portátil
    npm run dist
O executável sai em `dist/`.

## Notas
- Só altera o registo do utilizador (HKCU): não precisa de administrador.
- Backup dos valores originais em %APPDATA%\PrecisionFix\backup.json.
- Botão "Restaurar padrão" repõe tudo (exceto a cache do FiveM, que é apagada).
